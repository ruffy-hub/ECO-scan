from flask import Flask, request, jsonify
import numpy as np
import tensorflow as tf
from sklearn.preprocessing import LabelEncoder

app = Flask(_name_)
model = tf.keras.models.load_model('sustainability_model.h5')

le = LabelEncoder()
le.fit(['Plastic Bottle', 'Glass Bottle', 'Paper Bag', 'Cotton Shirt', 'Polyester Shirt', 'Electric Car', 'Gasoline Car'])

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    product_type = data['product_type']
    encoded = le.transform([product_type]).reshape(-1, 1)
    prediction = model.predict(encoded)
    return jsonify({
        "carbon_footprint": float(prediction[0][0]),
        "sustainability_score": float(prediction[0][1])
    })

if _name_ == '_main_':
    app.run(host='0.0.0.0', port=5000)