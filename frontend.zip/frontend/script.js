const apiUrl = 'https://your-backend-url.vercel.app/api';
const aiUrl = 'https://your-model-url.onrender.com/predict';

async function scanProduct() {
    const productName = document.getElementById('productInput').value;
    if (!productName) {
        alert('Please enter a product name');
        return;
    }

    const response = await fetch(aiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ product_type: productName })
    });

    const result = await response.json();
    document.getElementById('scanResult').innerText =
        `Carbon Footprint: ${result.carbon_footprint} kg CO2, 
        Sustainability Score: ${result.sustainability_score}/100.`;
}